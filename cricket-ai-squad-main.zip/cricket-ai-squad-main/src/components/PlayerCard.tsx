import { Player } from "@/lib/mockData";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Star } from "lucide-react";

interface PlayerCardProps {
  player: Player;
  onClick: () => void;
  isMainSquad?: boolean;
}

export const PlayerCard = ({ player, onClick, isMainSquad = true }: PlayerCardProps) => {
  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "Batsman": return "default";
      case "Bowler": return "secondary";
      case "All-Rounder": return "outline";
      case "Wicket-Keeper": return "destructive";
      default: return "default";
    }
  };

  return (
    <Card className="backdrop-blur-glass bg-white/80 border-white/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer group">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
              {player.name}
            </CardTitle>
            <Badge variant={getRoleBadgeVariant(player.role)} className="text-xs">
              {player.role}
            </Badge>
          </div>
          {isMainSquad && (
            <Star className="h-5 w-5 text-accent fill-accent" />
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="bg-gradient-card p-3 rounded-lg">
            <p className="text-muted-foreground text-xs">Matches</p>
            <p className="font-bold text-lg text-primary">{player.battingStats.matches}</p>
          </div>
          <div className="bg-gradient-card p-3 rounded-lg">
            <p className="text-muted-foreground text-xs">Runs</p>
            <p className="font-bold text-lg text-primary">{player.battingStats.runs}</p>
          </div>
          <div className="bg-gradient-card p-3 rounded-lg">
            <p className="text-muted-foreground text-xs">Average</p>
            <p className="font-bold text-lg text-secondary">{player.battingStats.average}</p>
          </div>
          <div className="bg-gradient-card p-3 rounded-lg">
            <p className="text-muted-foreground text-xs">SR</p>
            <p className="font-bold text-lg text-secondary">{player.battingStats.strikeRate}</p>
          </div>
        </div>

        {player.bowlingStats && (
          <div className="pt-2 border-t border-border/50">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Wickets:</span>
              <span className="font-semibold text-accent">{player.bowlingStats.wickets}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Economy:</span>
              <span className="font-semibold text-accent">{player.bowlingStats.economy}</span>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter>
        <Button 
          onClick={onClick} 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          <Eye className="mr-2 h-4 w-4" />
          View Profile
        </Button>
      </CardFooter>
    </Card>
  );
};
