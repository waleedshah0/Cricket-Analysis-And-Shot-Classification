export interface Player {
  id: number;
  name: string;
  role: "Batsman" | "Bowler" | "All-Rounder" | "Wicket-Keeper";
  battingStyle?: string;
  bowlingStyle?: string;
  battingStats: {
    matches: number;
    runs: number;
    average: number;
    strikeRate: number;
    hundreds: number;
    fifties: number;
  };
  bowlingStats?: {
    matches: number;
    wickets: number;
    average: number;
    economy: number;
    bestFigures: string;
  };
  formatPerformance: {
    format: string;
    matches: number;
    runs?: number;
    wickets?: number;
    average: number;
  }[];
  image?: string;
}

export interface Stadium {
  id: number;
  name: string;
  location: string;
  country: string;
}

export const STADIUMS: Stadium[] = [
  { id: 1, name: "Melbourne Cricket Ground", location: "Melbourne", country: "Australia" },
  { id: 2, name: "Lord's Cricket Ground", location: "London", country: "England" },
  { id: 3, name: "Eden Gardens", location: "Kolkata", country: "India" },
  { id: 4, name: "Wankhede Stadium", location: "Mumbai", country: "India" },
  { id: 5, name: "The Oval", location: "London", country: "England" },
  { id: 6, name: "Sydney Cricket Ground", location: "Sydney", country: "Australia" },
  { id: 7, name: "Gaddafi Stadium", location: "Lahore", country: "Pakistan" },
  { id: 8, name: "Newlands", location: "Cape Town", country: "South Africa" },
];

export const MOCK_PLAYERS: Player[] = [
  {
    id: 1,
    name: "Virat Kohli",
    role: "Batsman",
    battingStyle: "Right-hand Bat",
    battingStats: {
      matches: 274,
      runs: 13848,
      average: 58.67,
      strikeRate: 93.54,
      hundreds: 50,
      fifties: 72
    },
    formatPerformance: [
      { format: "Test", matches: 113, runs: 8848, average: 49.15 },
      { format: "ODI", matches: 292, runs: 13437, average: 58.18 },
      { format: "T20I", matches: 125, runs: 4037, average: 52.73 }
    ],
    image: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=400&h=400&fit=crop"
  },
  {
    id: 2,
    name: "Jasprit Bumrah",
    role: "Bowler",
    bowlingStyle: "Right-arm Fast",
    battingStats: {
      matches: 120,
      runs: 98,
      average: 7.54,
      strikeRate: 58.33,
      hundreds: 0,
      fifties: 0
    },
    bowlingStats: {
      matches: 120,
      wickets: 432,
      average: 20.73,
      economy: 4.32,
      bestFigures: "6/27"
    },
    formatPerformance: [
      { format: "Test", matches: 41, wickets: 173, average: 20.69 },
      { format: "ODI", matches: 89, wickets: 149, average: 23.55 },
      { format: "T20I", matches: 89, wickets: 110, average: 17.13 }
    ],
    image: "https://images.unsplash.com/photo-1546608235-3310a2494cdf?w=400&h=400&fit=crop"
  },
  {
    id: 3,
    name: "Ravindra Jadeja",
    role: "All-Rounder",
    battingStyle: "Left-hand Bat",
    bowlingStyle: "Slow Left-arm Orthodox",
    battingStats: {
      matches: 285,
      runs: 5541,
      average: 33.27,
      strikeRate: 86.45,
      hundreds: 4,
      fifties: 35
    },
    bowlingStats: {
      matches: 285,
      wickets: 502,
      average: 30.52,
      economy: 4.92,
      bestFigures: "5/16"
    },
    formatPerformance: [
      { format: "Test", matches: 78, runs: 3284, wickets: 306, average: 24.71 },
      { format: "ODI", matches: 197, runs: 2674, wickets: 220, average: 36.73 },
      { format: "T20I", matches: 74, runs: 583, wickets: 54, average: 29.74 }
    ],
    image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=400&h=400&fit=crop"
  },
  {
    id: 4,
    name: "KL Rahul",
    role: "Wicket-Keeper",
    battingStyle: "Right-hand Bat",
    battingStats: {
      matches: 168,
      runs: 6554,
      average: 45.89,
      strikeRate: 89.23,
      hundreds: 14,
      fifties: 38
    },
    formatPerformance: [
      { format: "Test", matches: 51, runs: 2981, average: 34.58 },
      { format: "ODI", matches: 60, runs: 2683, average: 45.64 },
      { format: "T20I", matches: 72, runs: 2890, average: 37.79 }
    ],
    image: "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=400&h=400&fit=crop"
  },
  {
    id: 5,
    name: "Rohit Sharma",
    role: "Batsman",
    battingStyle: "Right-hand Bat",
    battingStats: {
      matches: 454,
      runs: 18569,
      average: 45.35,
      strikeRate: 89.86,
      hundreds: 48,
      fifties: 106
    },
    formatPerformance: [
      { format: "Test", matches: 62, runs: 4301, average: 46.77 },
      { format: "ODI", matches: 265, runs: 10866, average: 48.96 },
      { format: "T20I", matches: 159, runs: 4231, average: 31.32 }
    ],
    image: "https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?w=400&h=400&fit=crop"
  },
  {
    id: 6,
    name: "Ben Stokes",
    role: "All-Rounder",
    battingStyle: "Left-hand Bat",
    bowlingStyle: "Right-arm Medium",
    battingStats: {
      matches: 324,
      runs: 12408,
      average: 38.66,
      strikeRate: 82.14,
      hundreds: 21,
      fifties: 61
    },
    bowlingStats: {
      matches: 324,
      wickets: 396,
      average: 31.95,
      economy: 5.34,
      bestFigures: "6/22"
    },
    formatPerformance: [
      { format: "Test", matches: 108, runs: 6405, wickets: 202, average: 31.72 },
      { format: "ODI", matches: 126, runs: 3269, wickets: 76, average: 43.03 },
      { format: "T20I", matches: 43, runs: 734, wickets: 37, average: 19.83 }
    ],
    image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&h=400&fit=crop"
  },
  {
    id: 7,
    name: "Kane Williamson",
    role: "Batsman",
    battingStyle: "Right-hand Bat",
    battingStats: {
      matches: 369,
      runs: 18374,
      average: 51.87,
      strikeRate: 78.93,
      hundreds: 49,
      fifties: 98
    },
    formatPerformance: [
      { format: "Test", matches: 100, runs: 8743, average: 54.64 },
      { format: "ODI", matches: 171, runs: 6952, average: 47.27 },
      { format: "T20I", matches: 98, runs: 2679, average: 32.41 }
    ],
    image: "https://images.unsplash.com/photo-1593341646782-e0b495cff86d?w=400&h=400&fit=crop"
  },
  {
    id: 8,
    name: "Pat Cummins",
    role: "Bowler",
    bowlingStyle: "Right-arm Fast",
    battingStats: {
      matches: 165,
      runs: 1876,
      average: 16.92,
      strikeRate: 73.45,
      hundreds: 0,
      fifties: 6
    },
    bowlingStats: {
      matches: 165,
      wickets: 488,
      average: 25.43,
      economy: 4.67,
      bestFigures: "6/23"
    },
    formatPerformance: [
      { format: "Test", matches: 62, wickets: 269, average: 22.08 },
      { format: "ODI", matches: 83, wickets: 171, average: 26.98 },
      { format: "T20I", matches: 56, wickets: 58, average: 25.91 }
    ],
    image: "https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=400&h=400&fit=crop"
  },
  {
    id: 9,
    name: "Shakib Al Hasan",
    role: "All-Rounder",
    battingStyle: "Left-hand Bat",
    bowlingStyle: "Slow Left-arm Orthodox",
    battingStats: {
      matches: 432,
      runs: 14271,
      average: 37.86,
      strikeRate: 81.23,
      hundreds: 18,
      fifties: 84
    },
    bowlingStats: {
      matches: 432,
      wickets: 712,
      average: 29.87,
      economy: 4.89,
      bestFigures: "7/36"
    },
    formatPerformance: [
      { format: "Test", matches: 71, runs: 4505, wickets: 246, average: 18.32 },
      { format: "ODI", matches: 247, runs: 7570, wickets: 317, average: 23.88 },
      { format: "T20I", matches: 129, runs: 2551, wickets: 149, average: 17.12 }
    ],
    image: "https://images.unsplash.com/photo-1626248106603-f9f3e3756e4d?w=400&h=400&fit=crop"
  },
  {
    id: 10,
    name: "Jos Buttler",
    role: "Wicket-Keeper",
    battingStyle: "Right-hand Bat",
    battingStats: {
      matches: 334,
      runs: 12543,
      average: 40.46,
      strikeRate: 98.76,
      hundreds: 26,
      fifties: 71
    },
    formatPerformance: [
      { format: "Test", matches: 70, runs: 3277, average: 32.77 },
      { format: "ODI", matches: 186, runs: 5092, average: 40.25 },
      { format: "T20I", matches: 124, runs: 3304, average: 34.41 }
    ],
    image: "https://images.unsplash.com/photo-1606925797300-0b35e9d1794e?w=400&h=400&fit=crop"
  },
  {
    id: 11,
    name: "Rashid Khan",
    role: "Bowler",
    bowlingStyle: "Leg Break Googly",
    battingStats: {
      matches: 198,
      runs: 1654,
      average: 14.82,
      strikeRate: 102.34,
      hundreds: 0,
      fifties: 3
    },
    bowlingStats: {
      matches: 198,
      wickets: 489,
      average: 17.54,
      economy: 5.87,
      bestFigures: "7/18"
    },
    formatPerformance: [
      { format: "Test", matches: 6, wickets: 34, average: 23.88 },
      { format: "ODI", matches: 98, wickets: 176, average: 18.32 },
      { format: "T20I", matches: 94, wickets: 166, average: 12.63 }
    ],
    image: "https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=400&h=400&fit=crop"
  },
  {
    id: 12,
    name: "Babar Azam",
    role: "Batsman",
    battingStyle: "Right-hand Bat",
    battingStats: {
      matches: 243,
      runs: 11467,
      average: 52.58,
      strikeRate: 84.32,
      hundreds: 31,
      fifties: 62
    },
    formatPerformance: [
      { format: "Test", matches: 57, runs: 3843, average: 42.70 },
      { format: "ODI", matches: 117, runs: 5729, average: 56.72 },
      { format: "T20I", matches: 123, runs: 3985, average: 41.93 }
    ],
    image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop"
  },
  {
    id: 13,
    name: "Trent Boult",
    role: "Bowler",
    bowlingStyle: "Left-arm Fast Medium",
    battingStats: {
      matches: 234,
      runs: 1234,
      average: 12.46,
      strikeRate: 65.78,
      hundreds: 0,
      fifties: 1
    },
    bowlingStats: {
      matches: 234,
      wickets: 610,
      average: 24.87,
      economy: 4.98,
      bestFigures: "7/34"
    },
    formatPerformance: [
      { format: "Test", matches: 81, wickets: 362, average: 27.49 },
      { format: "ODI", matches: 108, wickets: 207, average: 24.96 },
      { format: "T20I", matches: 62, wickets: 74, average: 21.62 }
    ],
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop"
  },
  {
    id: 14,
    name: "Quinton de Kock",
    role: "Wicket-Keeper",
    battingStyle: "Left-hand Bat",
    battingStats: {
      matches: 295,
      runs: 14324,
      average: 40.74,
      strikeRate: 89.34,
      hundreds: 29,
      fifties: 78
    },
    formatPerformance: [
      { format: "Test", matches: 54, runs: 3300, average: 38.82 },
      { format: "ODI", matches: 148, runs: 6418, average: 44.57 },
      { format: "T20I", matches: 86, runs: 2256, average: 31.00 }
    ],
    image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=400&h=400&fit=crop"
  },
  {
    id: 15,
    name: "Mitchell Starc",
    role: "Bowler",
    bowlingStyle: "Left-arm Fast",
    battingStats: {
      matches: 198,
      runs: 1987,
      average: 15.74,
      strikeRate: 71.23,
      hundreds: 0,
      fifties: 5
    },
    bowlingStats: {
      matches: 198,
      wickets: 578,
      average: 26.45,
      economy: 5.23,
      bestFigures: "6/28"
    },
    formatPerformance: [
      { format: "Test", matches: 89, wickets: 358, average: 27.87 },
      { format: "ODI", matches: 121, wickets: 247, average: 22.73 },
      { format: "T20I", matches: 67, wickets: 75, average: 21.45 }
    ],
    image: "https://images.unsplash.com/photo-1628260412297-a3377e45006f?w=400&h=400&fit=crop"
  },
];

export const generateSquad = (stadium: string, format: string): Player[] => {
  // Simulate squad selection with some randomization
  const shuffled = [...MOCK_PLAYERS].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, 15);
};
