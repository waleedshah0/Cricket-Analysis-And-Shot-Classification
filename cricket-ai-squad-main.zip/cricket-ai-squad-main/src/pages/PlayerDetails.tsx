import { useParams, useNavigate } from "react-router-dom";
import { MOCK_PLAYERS } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const PlayerDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const player = MOCK_PLAYERS.find((p) => p.id === Number(id));

  if (!player) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center">
        <Card className="backdrop-blur-glass bg-white/90">
          <CardHeader>
            <CardTitle>Player not found</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/generator")}>Back to Generator</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "Batsman": return "default";
      case "Bowler": return "secondary";
      case "All-Rounder": return "outline";
      case "Wicket-Keeper": return "destructive";
      default: return "default";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Button 
            variant="outline" 
            onClick={() => navigate("/generator")}
            className="mb-6 bg-card/90 backdrop-blur-sm hover:bg-card border-border"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Squad
          </Button>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Player Profile */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-1"
          >
            <Card className="backdrop-blur-glass bg-card/90 border-border/20 shadow-2xl sticky top-24">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-32 h-32 rounded-full overflow-hidden border-4 border-primary">
                <img 
                  src={player.image} 
                  alt={player.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardTitle className="text-2xl">{player.name}</CardTitle>
              <div className="flex justify-center gap-2 mt-2">
                <Badge variant={getRoleBadgeVariant(player.role)}>{player.role}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {player.battingStyle && (
                <div>
                  <p className="text-sm text-muted-foreground">Batting Style</p>
                  <p className="font-semibold">{player.battingStyle}</p>
                </div>
              )}
              {player.bowlingStyle && (
                <div>
                  <p className="text-sm text-muted-foreground">Bowling Style</p>
                  <p className="font-semibold">{player.bowlingStyle}</p>
                </div>
              )}
            </CardContent>
          </Card>
          </motion.div>

          {/* Stats Cards with Tabs */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3 bg-card/90">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="batting">Batting</TabsTrigger>
                <TabsTrigger value="bowling">Bowling</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <Card className="backdrop-blur-glass bg-card/90 border-border/20 shadow-xl">
                  <CardHeader>
                    <CardTitle>Format-wise Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={player.formatPerformance}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="format" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="matches" fill="hsl(var(--primary))" name="Matches" />
                        {player.formatPerformance[0].runs !== undefined && (
                          <Bar dataKey="runs" fill="hsl(var(--secondary))" name="Runs" />
                        )}
                        {player.formatPerformance[0].wickets !== undefined && (
                          <Bar dataKey="wickets" fill="hsl(var(--accent))" name="Wickets" />
                        )}
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="batting" className="space-y-6">
                <Card className="backdrop-blur-glass bg-card/90 border-border/20 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Batting Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gradient-card rounded-lg">
                    <p className="text-3xl font-bold text-primary">{player.battingStats.matches}</p>
                    <p className="text-sm text-muted-foreground">Matches</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-card rounded-lg">
                    <p className="text-3xl font-bold text-primary">{player.battingStats.runs}</p>
                    <p className="text-sm text-muted-foreground">Runs</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-card rounded-lg">
                    <p className="text-3xl font-bold text-primary">{player.battingStats.average}</p>
                    <p className="text-sm text-muted-foreground">Average</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-card rounded-lg">
                    <p className="text-3xl font-bold text-secondary">{player.battingStats.strikeRate}</p>
                    <p className="text-sm text-muted-foreground">Strike Rate</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-card rounded-lg">
                    <p className="text-3xl font-bold text-secondary">{player.battingStats.hundreds}</p>
                    <p className="text-sm text-muted-foreground">Hundreds</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-card rounded-lg">
                    <p className="text-3xl font-bold text-secondary">{player.battingStats.fifties}</p>
                    <p className="text-sm text-muted-foreground">Fifties</p>
                  </div>
                  </div>
                </CardContent>
              </Card>
              </TabsContent>

              <TabsContent value="bowling" className="space-y-6">
                {player.bowlingStats ? (
                  <Card className="backdrop-blur-glass bg-card/90 border-border/20 shadow-xl">
                <CardHeader>
                  <CardTitle>Bowling Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-gradient-card rounded-lg">
                      <p className="text-3xl font-bold text-primary">{player.bowlingStats.wickets}</p>
                      <p className="text-sm text-muted-foreground">Wickets</p>
                    </div>
                    <div className="text-center p-4 bg-gradient-card rounded-lg">
                      <p className="text-3xl font-bold text-primary">{player.bowlingStats.average}</p>
                      <p className="text-sm text-muted-foreground">Average</p>
                    </div>
                    <div className="text-center p-4 bg-gradient-card rounded-lg">
                      <p className="text-3xl font-bold text-secondary">{player.bowlingStats.economy}</p>
                      <p className="text-sm text-muted-foreground">Economy</p>
                    </div>
                    <div className="col-span-2 md:col-span-3 text-center p-4 bg-gradient-card rounded-lg">
                      <p className="text-3xl font-bold text-accent">{player.bowlingStats.bestFigures}</p>
                      <p className="text-sm text-muted-foreground">Best Figures</p>
                    </div>
                    </div>
                  </CardContent>
                </Card>
                ) : (
                  <Card className="backdrop-blur-glass bg-card/90 border-border/20 shadow-xl">
                    <CardContent className="py-12 text-center">
                      <p className="text-muted-foreground">No bowling statistics available</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default PlayerDetails;
