import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Upload, PlayCircle, TrendingUp, Activity, Target } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface AnalysisResult {
  shotsDetected: string[];
  footworkQuality: number;
  timingClassification: string;
  shotTypeRecognition: string[];
  balanceAnalysis: number;
  keyFrames: string[];
  recommendations: string[];
}

const BattingAnalysis = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const validTypes = ["video/mp4", "video/quicktime", "video/x-msvideo"];
      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please upload a .mp4, .mov, or .avi file",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedFile) return;

    setIsAnalyzing(true);
    setUploadProgress(0);

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    // Simulate API call
    setTimeout(() => {
      clearInterval(progressInterval);
      setUploadProgress(100);

      // Mock analysis result
      setAnalysisResult({
        shotsDetected: ["Cover Drive", "Pull Shot", "Straight Drive", "Cut Shot"],
        footworkQuality: 85,
        timingClassification: "Excellent",
        shotTypeRecognition: ["Offensive: 65%", "Defensive: 35%"],
        balanceAnalysis: 78,
        keyFrames: Array(6).fill("/placeholder.svg"),
        recommendations: [
          "Improve weight transfer on pull shots",
          "Maintain head position on cover drives",
          "Follow through completely on straight drives",
        ],
      });

      setIsAnalyzing(false);
      toast({
        title: "Analysis Complete!",
        description: "Your batting performance has been analyzed",
      });
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            AI Batting Performance Analyzer
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Upload your batting footage. AI will break down timing, footwork, balance & bat swing.
          </p>
        </motion.div>

        {!analysisResult ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="max-w-2xl mx-auto backdrop-blur-glass bg-card/90 border-border/50 shadow-2xl">
              <CardHeader>
                <CardTitle>Upload Batting Video</CardTitle>
                <CardDescription>Support: .mp4, .mov, .avi (Max 100MB)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="border-2 border-dashed border-border/50 rounded-lg p-12 text-center hover:border-primary/50 transition-colors cursor-pointer bg-gradient-card">
                  <input
                    type="file"
                    id="video-upload"
                    className="hidden"
                    accept=".mp4,.mov,.avi"
                    onChange={handleFileSelect}
                  />
                  <label htmlFor="video-upload" className="cursor-pointer">
                    <Upload className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-lg font-semibold mb-2">
                      {selectedFile ? selectedFile.name : "Click to upload or drag and drop"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Video files up to 100MB
                    </p>
                  </label>
                </div>

                {selectedFile && (
                  <div className="space-y-4">
                    {isAnalyzing && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Analyzing video...</span>
                          <span>{uploadProgress}%</span>
                        </div>
                        <Progress value={uploadProgress} />
                      </div>
                    )}

                    <Button
                      onClick={handleAnalyze}
                      disabled={isAnalyzing}
                      className="w-full h-12 text-lg bg-primary hover:bg-primary/90"
                    >
                      {isAnalyzing ? (
                        <>
                          <Activity className="mr-2 h-5 w-5 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <PlayCircle className="mr-2 h-5 w-5" />
                          Start AI Analysis
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-8"
          >
            {/* Video Player */}
            <Card className="backdrop-blur-glass bg-card/90 border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PlayCircle className="h-5 w-5" />
                  Analysis Video
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <PlayCircle className="h-16 w-16 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="backdrop-blur-glass bg-card/90 border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Footwork Quality</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-primary mb-2">
                    {analysisResult.footworkQuality}%
                  </div>
                  <Progress value={analysisResult.footworkQuality} className="mb-2" />
                  <p className="text-sm text-muted-foreground">Excellent positioning</p>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-glass bg-card/90 border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Balance Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-secondary mb-2">
                    {analysisResult.balanceAnalysis}%
                  </div>
                  <Progress value={analysisResult.balanceAnalysis} className="mb-2" />
                  <p className="text-sm text-muted-foreground">Good stability</p>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-glass bg-card/90 border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Timing</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-accent mb-2">
                    {analysisResult.timingClassification}
                  </div>
                  <Badge className="bg-accent text-accent-foreground">
                    <Target className="h-3 w-3 mr-1" />
                    Top Performance
                  </Badge>
                </CardContent>
              </Card>
            </div>

            {/* Shots Detected */}
            <Card className="backdrop-blur-glass bg-card/90 border-border/50">
              <CardHeader>
                <CardTitle>Shots Detected</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {analysisResult.shotsDetected.map((shot, idx) => (
                    <Badge key={idx} variant="secondary" className="text-sm">
                      {shot}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* AI Recommendations */}
            <Card className="backdrop-blur-glass bg-card/90 border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  AI Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analysisResult.recommendations.map((rec, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 bg-gradient-card rounded-lg">
                      <div className="h-6 w-6 rounded-full bg-primary/20 text-primary flex items-center justify-center text-sm font-bold">
                        {idx + 1}
                      </div>
                      <p className="text-sm flex-1">{rec}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Key Frames */}
            <Card className="backdrop-blur-glass bg-card/90 border-border/50">
              <CardHeader>
                <CardTitle>Key Frames</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {analysisResult.keyFrames.map((frame, idx) => (
                    <div key={idx} className="aspect-video bg-muted rounded-lg overflow-hidden">
                      <img src={frame} alt={`Frame ${idx + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={() => {
                setAnalysisResult(null);
                setSelectedFile(null);
                setUploadProgress(0);
              }}
              className="w-full max-w-md mx-auto block"
            >
              Analyze Another Video
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default BattingAnalysis;
