import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { STADIUMS, generateSquad, Player } from "@/lib/mockData";
import { Sparkles, MapPin, Trophy, Share2 } from "lucide-react";
import { PlayerCard } from "@/components/PlayerCard";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

const SquadGenerator = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [stadium, setStadium] = useState<string>("");
  const [format, setFormat] = useState<string>("");
  const [squad, setSquad] = useState<Player[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateSquad = async () => {
    if (!stadium || !format) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const generatedSquad = generateSquad(stadium, format);
    setSquad(generatedSquad);
    setIsLoading(false);
    
    toast({
      title: "Squad Generated!",
      description: `Your ${format} squad for ${stadium} is ready.`,
    });
  };

  const handleShareSquad = () => {
    toast({
      title: "Share Squad",
      description: "Squad link copied to clipboard!",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="text-4xl md:text-5xl font-poppins font-bold text-white mb-4 flex items-center justify-center gap-3 text-glow-primary">
            <Sparkles className="h-8 w-8 animate-pulse-glow" />
            Squad Generator
          </h1>
          <p className="text-foreground text-lg">Select stadium and format to get AI-powered recommendations</p>
        </motion.div>

        {/* Generator Form */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="max-w-2xl mx-auto mb-12 glass-card shadow-neon-primary">
            <CardHeader>
              <CardTitle className="text-white">Configure Selection</CardTitle>
              <CardDescription className="text-muted-foreground">Choose your match conditions</CardDescription>
            </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="stadium" className="text-base flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Stadium Name
              </Label>
              <Select value={stadium} onValueChange={setStadium}>
                <SelectTrigger id="stadium">
                  <SelectValue placeholder="Select a stadium" />
                </SelectTrigger>
                <SelectContent className="bg-card">
                  {STADIUMS.map((s) => (
                    <SelectItem key={s.id} value={s.name}>
                      {s.name}, {s.location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="format" className="text-base flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Match Format
              </Label>
              <Select value={format} onValueChange={setFormat}>
                <SelectTrigger id="format">
                  <SelectValue placeholder="Select match format" />
                </SelectTrigger>
                <SelectContent className="bg-card">
                  <SelectItem value="Test">Test Cricket</SelectItem>
                  <SelectItem value="ODI">One Day International (ODI)</SelectItem>
                  <SelectItem value="T20I">Twenty20 International (T20I)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              onClick={handleGenerateSquad} 
              disabled={!stadium || !format || isLoading}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 text-lg font-semibold"
            >
              {isLoading ? (
                <>
                  <Sparkles className="mr-2 h-5 w-5 animate-spin" />
                  Generating Squad...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Generate AI Squad
                </>
              )}
            </Button>
          </CardContent>
        </Card>
        </motion.div>

        {/* Loading Skeletons */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(15).fill(0).map((_, idx) => (
              <Card key={idx} className="backdrop-blur-glass bg-card/90">
                <CardHeader>
                  <Skeleton className="h-48 w-full" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Squad Results */}
        {squad && !isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="mb-8 text-center">
              <h2 className="text-3xl font-bold text-white mb-2">Your Selected Squad</h2>
              <p className="text-white/80 mb-4">15 Players - Playing XI + 4 Backups</p>
              
              <Button
                onClick={handleShareSquad}
                variant="secondary"
                className="gap-2"
              >
                <Share2 className="h-4 w-4" />
                Share Squad
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {squad.map((player, index) => (
                <motion.div
                  key={player.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <PlayerCard 
                    player={player} 
                    onClick={() => navigate(`/player/${player.id}`)}
                    isMainSquad={index < 11}
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default SquadGenerator;
